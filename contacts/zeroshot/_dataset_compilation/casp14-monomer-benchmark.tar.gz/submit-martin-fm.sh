#!/bin/sh -e

OUTDIR="/storage/mmirdit/casp14/monomer-bfloat16"
CSVDIR="fasta-fm"

mkdir -p "${OUTDIR}"
for i in ${CSVDIR}/*.fasta; do
    FULL=$(readlink -f $i)
    BASE=$(basename ${FULL%.*})
    MODEL1=$(echo "${OUTDIR}/${BASE}/"*"_unrelaxed_model_1.pdb")
    if [ -e "${MODEL1}" ]; then
        continue
    fi
    sbatch -o "${OUTDIR}/${BASE}.slurm" -p gpu --gres=gpu:1 -t 1-0 -c 4 /storage/mmirdit/casp14/run_colabfold.sh "$FULL" "${OUTDIR}/$BASE" --use-bfloat16
done
