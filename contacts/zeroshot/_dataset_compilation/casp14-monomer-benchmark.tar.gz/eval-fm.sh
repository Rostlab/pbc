#!/bin/bash -ex
BASE="${1}"
shopt -s nullglob
for i in pdb-domain/*; do
    PDB=$(basename $i .pdb);
    TARGET=$(echo $PDB | cut -d'-' -f1);
    MODEL=$(echo "${BASE}/${TARGET}/"*"_rank_1_"*".pdb")
    if [ -e "${MODEL}" ]; then
        SCORE=$(./TMalign "$i" "${MODEL}" | awk '/^TM-score=/ { print $2; exit}')
        printf "%s %f\n" ${PDB} ${SCORE}
    fi
done > "${BASE}/eval.tsv"
