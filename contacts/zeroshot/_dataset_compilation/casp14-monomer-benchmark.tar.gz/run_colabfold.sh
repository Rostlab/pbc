#!/bin/bash -ex
INPUT=$1
OUTPUT=$2
shift
shift
unset CONDA_SHLVL
eval "$(conda shell.bash hook)"
conda activate colabfold-3.7
export TF_FORCE_UNIFIED_MEMORY=1
export XLA_PYTHON_CLIENT_MEM_FRACTION=2.0
mkdir -p ${OUTPUT}
/usr/bin/time -v colabfold_batch "$INPUT" "$OUTPUT" --env "$@" 2>&1 | tee "${OUTPUT}.log"
